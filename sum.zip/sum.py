import json
from datetime import datetime

def lambda_handler(event, context):
    # Your code logic here
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    return {
        'statusCode': 200,
        'body': json.dumps(f'Hello from Lambda! The current time is {current_time}.')
    }